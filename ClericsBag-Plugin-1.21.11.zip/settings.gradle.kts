rootProject.name = "ClericsBag"
