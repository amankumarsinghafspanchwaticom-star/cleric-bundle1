package com.clericsbag.command;

import com.clericsbag.ClericsBagPlugin;
import com.clericsbag.bag.ClericsBagManager;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public final class ClericsBagCommand implements CommandExecutor, TabCompleter {

    private final ClericsBagPlugin plugin;
    private final ClericsBagManager bagManager;

    public ClericsBagCommand(ClericsBagPlugin plugin, ClericsBagManager bagManager) {
        this.plugin = plugin;
        this.bagManager = bagManager;
    }

    @Override
    public boolean onCommand(
            @NotNull CommandSender sender,
            @NotNull Command command,
            @NotNull String label,
            @NotNull String[] args
    ) {
        if (args.length == 0) {
            sender.sendMessage(plugin.parse("<gray>Usage: /clericsbag <give|reload> [player]</gray>"));
            return true;
        }

        switch (args[0].toLowerCase()) {
            case "give" -> {
                if (!sender.hasPermission("clericsbag.admin.give")) {
                    sender.sendMessage(plugin.msg("no-permission"));
                    return true;
                }
                Player target;
                if (args.length >= 2) {
                    target = Bukkit.getPlayerExact(args[1]);
                    if (target == null) {
                        sender.sendMessage(plugin.parse("<red>Player not found: " + args[1] + "</red>"));
                        return true;
                    }
                } else if (sender instanceof Player p) {
                    target = p;
                } else {
                    sender.sendMessage(plugin.parse("<red>Specify a player from console.</red>"));
                    return true;
                }

                ItemStack bag = bagManager.createClericsBag();
                Map<Integer, ItemStack> overflow = target.getInventory().addItem(bag);
                overflow.values().forEach(drop -> target.getWorld().dropItemNaturally(target.getLocation(), drop));
                sender.sendMessage(plugin.parse("<green>Gave <gold><bold>Cleric's Bag</bold></gold> to <white>" + target.getName() + "</white>.</green>"));
            }
            case "reload" -> {
                if (!sender.hasPermission("clericsbag.admin.reload")) {
                    sender.sendMessage(plugin.msg("no-permission"));
                    return true;
                }
                plugin.reloadConfig();
                bagManager.registerRecipe();
                sender.sendMessage(plugin.msg("reloaded"));
            }
            default -> sender.sendMessage(plugin.parse("<gray>Usage: /clericsbag <give|reload> [player]</gray>"));
        }
        return true;
    }

    @Override
    public @Nullable List<String> onTabComplete(
            @NotNull CommandSender sender,
            @NotNull Command command,
            @NotNull String alias,
            @NotNull String[] args
    ) {
        if (args.length == 1) {
            return List.of("give", "reload").stream()
                    .filter(s -> s.startsWith(args[0].toLowerCase()))
                    .toList();
        }
        if (args.length == 2 && args[0].equalsIgnoreCase("give")) {
            List<String> names = new ArrayList<>();
            for (Player p : Bukkit.getOnlinePlayers()) {
                if (p.getName().toLowerCase().startsWith(args[1].toLowerCase())) {
                    names.add(p.getName());
                }
            }
            return names;
        }
        return List.of();
    }
}
