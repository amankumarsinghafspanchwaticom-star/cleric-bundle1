package com.clericsbag.listener;

import com.clericsbag.ClericsBagPlugin;
import com.clericsbag.bag.ClericsBagManager;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;

import java.util.List;

public final class ClericsBagListener implements Listener {

    private final ClericsBagPlugin plugin;
    private final ClericsBagManager bagManager;

    public ClericsBagListener(ClericsBagPlugin plugin, ClericsBagManager bagManager) {
        this.plugin = plugin;
        this.bagManager = bagManager;
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onRightClickInHand(PlayerInteractEvent event) {
        if (event.getHand() != EquipmentSlot.HAND) {
            return;
        }
        Action action = event.getAction();
        if (action != Action.RIGHT_CLICK_AIR && action != Action.RIGHT_CLICK_BLOCK) {
            return;
        }

        ItemStack item = event.getItem();
        if (!bagManager.isClericsBag(item)) {
            return;
        }

        Player player = event.getPlayer();
        event.setCancelled(true);

        if (!player.hasPermission("clericsbag.use")) {
            player.sendMessage(plugin.msg("no-permission"));
            return;
        }

        // Shift + Right-Click rotates potion order in-place without dumping or removing items
        if (player.isSneaking()) {
            if (bagManager.rotateOrder(item)) {
                player.playSound(player.getLocation(), Sound.ITEM_BUNDLE_INSERT, 0.9f, 1.25f);
                List<ItemStack> nowOrdered = bagManager.readPotionsInOrder(item);
                String nextName = nowOrdered.isEmpty() ? "None" : bagManager.describePotion(nowOrdered.get(0));
                player.sendActionBar(plugin.parse("<aqua>Reordered bag — next potion: <white>" + nextName + "</white></aqua>"));
            }
            return;
        }

        ClericsBagManager.PopResult result = bagManager.popNextPotion(item);
        if (result.potion() == null) {
            player.sendActionBar(plugin.rawMsg("empty-bag"));
            player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_BASS, 0.7f, 0.8f);
            return;
        }

        bagManager.launchPotion(player, result.potion());
        player.playSound(player.getLocation(), Sound.ENTITY_SPLASH_POTION_THROW, 0.95f, 1.05f);

        String raw = plugin.getConfig().getString("messages.threw-potion", "")
                .replace("{potion}", bagManager.describePotion(result.potion()))
                .replace("{remaining}", String.valueOf(result.remaining()));
        player.sendActionBar(plugin.parse(raw));
    }

    /**
     * Allows adding potions up to 16 and rearranging order inside the bag without emptying everything:
     * - Click on Cleric's Bag while holding a potion on cursor -> appends that potion (up to 16).
     * - Right-click on Cleric's Bag with an empty cursor -> rotates order so the back/next potion shifts forward.
     * - Middle-click or Shift-left-click on Cleric's Bag -> moves the first potion to the back without dumping items.
     */
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onInventoryBagInteract(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) {
            return;
        }

        ItemStack clickedBag = event.getCurrentItem();
        if (!bagManager.isClericsBag(clickedBag)) {
            return;
        }

        ItemStack cursor = event.getCursor();
        ClickType click = event.getClick();

        // Inserting a potion from cursor into the bag
        if (bagManager.isSupportedPotion(cursor)) {
            event.setCancelled(true);
            if (bagManager.insertPotion(clickedBag, cursor)) {
                cursor.setAmount(cursor.getAmount() - 1);
                player.setCursor(cursor.getAmount() > 0 ? cursor : new ItemStack(Material.AIR));
                player.playSound(player.getLocation(), Sound.ITEM_BUNDLE_INSERT, 0.9f, 1.1f);
                int count = bagManager.readPotionsInOrder(clickedBag).size();
                player.sendActionBar(plugin.parse("<green>Added potion to Cleric's Bag (<white>" + count + "/" + bagManager.getMaxPotions() + "</white>).</green>"));
            } else {
                player.sendActionBar(plugin.parse("<red>Cleric's Bag is full (max <white>" + bagManager.getMaxPotions() + "</white> potions)!</red>"));
            }
            return;
        }

        // Right-clicking the bag with empty cursor rotates potion order in-place without emptying
        if (click == ClickType.RIGHT && (cursor == null || cursor.getType().isAir())) {
            event.setCancelled(true);
            if (bagManager.rotateOrder(clickedBag)) {
                player.playSound(player.getLocation(), Sound.ITEM_BUNDLE_REMOVE_ONE, 0.85f, 1.2f);
                List<ItemStack> ordered = bagManager.readPotionsInOrder(clickedBag);
                String nextName = ordered.isEmpty() ? "None" : bagManager.describePotion(ordered.get(0));
                player.sendActionBar(plugin.parse("<aqua>Order shifted — next potion: <white>" + nextName + "</white></aqua>"));
            }
        }
    }
}
