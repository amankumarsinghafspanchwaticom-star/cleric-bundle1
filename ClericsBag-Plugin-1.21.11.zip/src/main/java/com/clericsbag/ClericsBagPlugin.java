package com.clericsbag;

import com.clericsbag.bag.ClericsBagManager;
import com.clericsbag.command.ClericsBagCommand;
import com.clericsbag.listener.ClericsBagListener;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.command.PluginCommand;
import org.bukkit.plugin.PluginManager;
import org.bukkit.plugin.java.JavaPlugin;

public final class ClericsBagPlugin extends JavaPlugin {

    private static final MiniMessage MINI_MESSAGE = MiniMessage.miniMessage();

    private ClericsBagManager bagManager;

    @Override
    public void onEnable() {
        saveDefaultConfig();

        this.bagManager = new ClericsBagManager(this);
        this.bagManager.registerRecipe();

        PluginManager pm = getServer().getPluginManager();
        pm.registerEvents(new ClericsBagListener(this, bagManager), this);

        PluginCommand cmd = getCommand("clericsbag");
        if (cmd != null) {
            ClericsBagCommand executor = new ClericsBagCommand(this, bagManager);
            cmd.setExecutor(executor);
            cmd.setTabCompleter(executor);
        }

        getLogger().info("ClericsBag enabled.");
    }

    @Override
    public void onDisable() {
        if (bagManager != null) {
            bagManager.unregisterRecipe();
        }
    }

    public ClericsBagManager getBagManager() {
        return bagManager;
    }

    public Component msg(String path) {
        String prefix = getConfig().getString("messages.prefix", "");
        String raw = getConfig().getString("messages." + path, "");
        return MINI_MESSAGE.deserialize(prefix + raw);
    }

    public Component rawMsg(String path) {
        String raw = getConfig().getString("messages." + path, "");
        return MINI_MESSAGE.deserialize(raw);
    }

    public Component parse(String miniMessage) {
        return MINI_MESSAGE.deserialize(miniMessage);
    }
}
