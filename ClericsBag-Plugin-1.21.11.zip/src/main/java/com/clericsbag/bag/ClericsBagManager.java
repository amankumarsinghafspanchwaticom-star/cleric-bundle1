package com.clericsbag.bag;

import com.clericsbag.ClericsBagPlugin;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.entity.ThrownPotion;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.ShapedRecipe;
import org.bukkit.inventory.meta.BundleMeta;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.PotionMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.util.Vector;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class ClericsBagManager {

    private final ClericsBagPlugin plugin;
    private final NamespacedKey bagKey;
    private final NamespacedKey recipeKey;

    public ClericsBagManager(ClericsBagPlugin plugin) {
        this.plugin = plugin;
        this.bagKey = new NamespacedKey(plugin, "clerics_bag");
        this.recipeKey = new NamespacedKey(plugin, "clerics_bag_recipe");
    }

    public NamespacedKey getRecipeKey() {
        return recipeKey;
    }

    public ItemStack createClericsBag() {
        ItemStack bag = new ItemStack(Material.BUNDLE, 1);
        ItemMeta meta = bag.getItemMeta();
        if (meta == null) {
            return bag;
        }

        String rawName = plugin.getConfig().getString("bag.name", "<gold><bold>Cleric's Bag</bold></gold>");
        Component name = plugin.parse(rawName)
                .decorationIfAbsent(TextDecoration.ITALIC, TextDecoration.State.FALSE);
        meta.displayName(name);

        List<String> loreLines = plugin.getConfig().getStringList("bag.lore");
        if (!loreLines.isEmpty()) {
            List<Component> lore = loreLines.stream()
                    .map(line -> plugin.parse(line)
                            .decorationIfAbsent(TextDecoration.ITALIC, TextDecoration.State.FALSE))
                    .toList();
            meta.lore(lore);
        }

        meta.getPersistentDataContainer().set(bagKey, PersistentDataType.BYTE, (byte) 1);
        bag.setItemMeta(meta);
        return bag;
    }

    public boolean isClericsBag(ItemStack item) {
        if (item == null || item.getType() != Material.BUNDLE || !item.hasItemMeta()) {
            return false;
        }
        ItemMeta meta = item.getItemMeta();
        return meta != null && meta.getPersistentDataContainer().has(bagKey, PersistentDataType.BYTE);
    }

    public boolean isSupportedPotion(ItemStack item) {
        if (item == null || item.getType().isAir()) {
            return false;
        }
        Material type = item.getType();
        return type == Material.POTION
                || type == Material.SPLASH_POTION
                || type == Material.LINGERING_POTION;
    }

    public int getMaxPotions() {
        int configured = plugin.getConfig().getInt("bag.max-potions", 16);
        return Math.max(1, Math.min(16, configured));
    }

    /**
     * Expands BundleMeta items into a flat ordered list of single-potion ItemStacks.
     * Index 0 is the front/next potion to throw; appending adds to the back of the queue.
     */
    public List<ItemStack> readPotionsInOrder(ItemStack bag) {
        List<ItemStack> ordered = new ArrayList<>();
        if (!isClericsBag(bag)) {
            return ordered;
        }
        ItemMeta meta = bag.getItemMeta();
        if (!(meta instanceof BundleMeta bundleMeta) || !bundleMeta.hasItems()) {
            return ordered;
        }
        for (ItemStack entry : bundleMeta.getItems()) {
            if (!isSupportedPotion(entry)) {
                continue;
            }
            int count = Math.max(1, entry.getAmount());
            for (int i = 0; i < count; i++) {
                ItemStack single = entry.clone();
                single.setAmount(1);
                ordered.add(single);
            }
        }
        return ordered;
    }

    public void writePotionsInOrder(ItemStack bag, List<ItemStack> orderedPotions) {
        if (!isClericsBag(bag)) {
            return;
        }
        int limit = getMaxPotions();
        List<ItemStack> trimmed = orderedPotions.size() > limit
                ? new ArrayList<>(orderedPotions.subList(0, limit))
                : new ArrayList<>(orderedPotions);

        ItemMeta meta = bag.getItemMeta();
        if (!(meta instanceof BundleMeta bundleMeta)) {
            return;
        }
        bundleMeta.setItems(trimmed);
        bag.setItemMeta(bundleMeta);
    }

    public boolean insertPotion(ItemStack bag, ItemStack incomingSingle) {
        if (!isClericsBag(bag) || !isSupportedPotion(incomingSingle)) {
            return false;
        }
        List<ItemStack> current = readPotionsInOrder(bag);
        if (current.size() >= getMaxPotions()) {
            return false;
        }
        ItemStack single = incomingSingle.clone();
        single.setAmount(1);
        current.add(single);
        writePotionsInOrder(bag, current);
        return true;
    }

    /**
     * Pops and throws the next potion at index 0 (queue order), preserving the order of remaining potions.
     */
    public PopResult popNextPotion(ItemStack bag) {
        List<ItemStack> current = readPotionsInOrder(bag);
        if (current.isEmpty()) {
            return new PopResult(null, 0);
        }
        ItemStack next = current.remove(0);
        writePotionsInOrder(bag, current);
        return new PopResult(next, current.size());
    }

    /**
     * Moves the potion at fromIndex to toIndex without removing other potions from the bag.
     */
    public boolean movePotion(ItemStack bag, int fromIndex, int toIndex) {
        List<ItemStack> current = readPotionsInOrder(bag);
        if (fromIndex < 0 || fromIndex >= current.size() || toIndex < 0 || toIndex >= current.size()) {
            return false;
        }
        if (fromIndex == toIndex) {
            return true;
        }
        ItemStack moved = current.remove(fromIndex);
        current.add(toIndex, moved);
        writePotionsInOrder(bag, current);
        return true;
    }

    /**
     * Rotates the potion order by 1 step so the user can cycle/reorder the front potion without emptying.
     */
    public boolean rotateOrder(ItemStack bag) {
        List<ItemStack> current = readPotionsInOrder(bag);
        if (current.size() <= 1) {
            return false;
        }
        ItemStack first = current.remove(0);
        current.add(first);
        writePotionsInOrder(bag, current);
        return true;
    }

    public void launchPotion(Player thrower, ItemStack potionItem) {
        if (thrower == null || potionItem == null || potionItem.getType().isAir()) {
            return;
        }
        double speed = plugin.getConfig().getDouble("bag.throw-speed", 1.35);
        Vector velocity = thrower.getEyeLocation().getDirection().normalize().multiply(speed);

        ItemStack projectileStack = potionItem.clone();
        projectileStack.setAmount(1);
        if (projectileStack.getType() == Material.POTION) {
            projectileStack.setType(Material.SPLASH_POTION);
        }

        ThrownPotion thrown = thrower.launchProjectile(ThrownPotion.class, velocity);
        thrown.setShooter(thrower);
        thrown.setItem(projectileStack);
    }

    public String describePotion(ItemStack potion) {
        if (potion == null || potion.getType().isAir()) {
            return "Potion";
        }
        if (potion.hasItemMeta() && potion.getItemMeta() instanceof PotionMeta pm && pm.getBasePotionType() != null) {
            String raw = pm.getBasePotionType().name().toLowerCase(Locale.ROOT).replace('_', ' ');
            return raw.substring(0, 1).toUpperCase(Locale.ROOT) + raw.substring(1);
        }
        String mat = potion.getType().name().toLowerCase(Locale.ROOT).replace('_', ' ');
        return mat.substring(0, 1).toUpperCase(Locale.ROOT) + mat.substring(1);
    }

    public void registerRecipe() {
        unregisterRecipe();
        if (!plugin.getConfig().getBoolean("crafting.enabled", true)) {
            return;
        }

        List<String> shape = plugin.getConfig().getStringList("crafting.shape");
        if (shape.size() != 3) {
            shape = List.of("SLS", "LBL", "SLS");
        }

        ShapedRecipe recipe = new ShapedRecipe(recipeKey, createClericsBag());
        recipe.shape(shape.get(0), shape.get(1), shape.get(2));

        ConfigurationSection ing = plugin.getConfig().getConfigurationSection("crafting.ingredients");
        if (ing != null) {
            for (String key : ing.getKeys(false)) {
                if (key.length() != 1) {
                    continue;
                }
                Material mat = Material.matchMaterial(ing.getString(key, ""));
                if (mat != null && !mat.isAir()) {
                    recipe.setIngredient(key.charAt(0), mat);
                }
            }
        } else {
            recipe.setIngredient('S', Material.STRING);
            recipe.setIngredient('L', Material.LEATHER);
            recipe.setIngredient('B', Material.BUNDLE);
        }

        Bukkit.addRecipe(recipe);
    }

    public void unregisterRecipe() {
        Bukkit.removeRecipe(recipeKey);
    }

    public record PopResult(ItemStack potion, int remaining) {
    }
}
